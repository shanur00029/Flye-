from django.apps import AppConfig


class UploadappConfig(AppConfig):
    name = 'uploadapp'
